module.exports = {
	mongo : {
   		user: 		"admin",
   		password: 	"r6wWkmkfyItZ",
   		db: 		"skyshares"
   	}
};

//ssh://559d60dae0b8cd2de5000097@skyshares-walice.rhcloud.com/~/git/skyshares.git/